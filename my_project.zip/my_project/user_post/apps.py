from django.apps import AppConfig


class UserPostConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'user_post'
